import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {
  transactions:string[];
  constructor(private router: Router, private userService:BankServiceService) { }

  ngOnInit() {
 
  
    this.userService.getTransactionsByAccountNo().subscribe(data => {
    this.transactions = data;
      console.log(this.transactions);
  });
  }
}
