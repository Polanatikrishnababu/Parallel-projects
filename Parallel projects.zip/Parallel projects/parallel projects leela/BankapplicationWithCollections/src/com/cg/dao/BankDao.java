package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.BankBean;

public class BankDao {

	BankBean bankBeanObj;
	HashMap<Long, BankBean> hashmap= new HashMap<Long, BankBean>(); 
	
	public void addCustomer(BankBean BeanObj)
	{
	this.bankBeanObj = BeanObj;
	hashmap.put(bankBeanObj.getAccNo(), BeanObj); 
	}
	 public HashMap<Long, BankBean> hm(){  
	return hashmap;
	 }

}