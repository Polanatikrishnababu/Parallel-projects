package com.ui;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;
import com.bean.BankBean;
import com.service.BankService;

public class BankModules {
	BankService bankServiceObj = new BankService();
	Scanner sc = new Scanner(System.in);

	public void accountCreation() {
		System.out.print("Enter Name: ");
		String name = nameCheck(sc.next());
		System.out.print("Enter Mobile No.: ");
		long mobno = mobileNumberCheck(sc.nextLong());
		long accno = 52345676 + mobno ;
		System.out.print("Enter Balance: ");
		float balance = amountCheck(sc.nextFloat());
		BankBean CreateAccountObj = new BankBean(accno, name, mobno, balance);
		System.out.println("Account created with Account Number: " +accno);
		bankServiceObj.bankAccountCreateService(CreateAccountObj);

	}

	public void balanceCheck() {
		System.out.print("Enter Account Number: ");
		long accno = sc.nextLong();
		BankBean ShowBalObj = new BankBean(accno);
		bankServiceObj.BalanceService(ShowBalObj);

	}

	public void deposit() {
		System.out.print("Enter Account Number: ");
		long accno = sc.nextLong();
		System.out.print("Enter Deposit Amount: ");
		float depAmount = amountCheck(sc.nextFloat());
		BankBean DepositObj = new BankBean(accno, depAmount);
		bankServiceObj.depositService(DepositObj);
	}

	public void withdraw() {
		System.out.print("Enter Account Number: ");
		long accno = sc.nextLong();
		System.out.print("Enter Withdraw Amount: ");
		float withdrawAmount = amountCheck(sc.nextFloat());
		BankBean WithdrawObj = new BankBean(withdrawAmount, accno);
		bankServiceObj.withdrawService(WithdrawObj);
	}

	public void fundTransfer() {
		System.out.println("Enter Source Account Number: ");
		long sourceAccNo = sc.nextLong();
		System.out.println("Enter Destination Account Number: ");
		long destinationAccNo = sc.nextLong();
		System.out.println("Enter Amount to transfer: ");
		float transferAmount = amountCheck(sc.nextFloat());
		BankBean FundTransferObj = new BankBean(sourceAccNo, destinationAccNo, transferAmount);
		bankServiceObj.transferService(FundTransferObj);
		String transactions = transferAmount + " transferred from Account number " + sourceAccNo + " to " + destinationAccNo;
		FundTransferObj = new BankBean(transactions);
	}

	public void printTransactions() {
		System.out.println(Arrays.toString(BankBean.transactions));
	}

	public float amountCheck(float amount) {
		while (true) {
			if (amount <= 0) {
				System.out.println("Amount should be greater than 0.");
				System.out.println("Enter again: ");
				amount = sc.nextInt();
			} else {
				return amount;
			}
		}
	}

	public String nameCheck(String name) {
		while (true) {
			if (Pattern.matches("([A-Z])*([a-z])*", name)) {
				return name;
			} else {
				System.out.println("Name should only have alphabets.");
				System.out.println("Enter again: ");
				name = sc.next();
			}
		}
	}

	public long mobileNumberCheck(long mob) {
		while (true) {
			if (String.valueOf(mob).length() < 10) {
				System.out.println("Enter valid mobile number.");
				mob = sc.nextLong();
			} else {
				return mob;
			}
		}
	}
}