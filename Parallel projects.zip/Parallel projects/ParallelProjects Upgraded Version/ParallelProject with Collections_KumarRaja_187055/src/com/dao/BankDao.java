package com.dao;
import java.util.HashMap;
import com.bean.BankBean;
public class BankDao 
{
   BankBean beankBeanObj;
   HashMap<Long, BankBean> hm = new HashMap<Long, BankBean>();
   public void addCustomer(BankBean beankBeanObj) 
   {			 
	   this.beankBeanObj = beankBeanObj;						
	   hm.put(beankBeanObj.getAccNo(), beankBeanObj);			

	}
   public HashMap<Long, BankBean> hm()
   {				
	   return hm;
   }
}
