package com.service;
import com.bean.BankBean;
import com.dao.BankDao;
public class BankService {

	BankDao Dao = new BankDao();

	public void bankAccountCreateService(BankBean bankBeanObjCreateAccountObj) 
	{
		Dao.addCustomer(bankBeanObjCreateAccountObj);
	}

	public void BalanceService(BankBean bankBeanShowBalObj){
		if (Dao.hm().isEmpty()){
			System.out.println("Please create an account first.");
		} else {
			if (Dao.hm().containsKey(bankBeanShowBalObj.getAccNo())) {
				System.out.println(
						"Your Account Balance is: " + Dao.hm().get(bankBeanShowBalObj.getAccNo()).getBalance());
			} else {
				System.out.println("No such Account Exist.");
			}
		}
	}

	public void depositService(BankBean bankBeanDepObj) {

		if (Dao.hm().isEmpty()) {
			System.out.println("Please create an account first.");
		} else {

			if (Dao.hm().containsKey(bankBeanDepObj.getAccNo())) {
				float dep = bankBeanDepObj.getDepAmount() + Dao.hm().get(bankBeanDepObj.getAccNo()).getBalance();
				Dao.hm().get(bankBeanDepObj.getAccNo()).setBalance(dep);
				System.out.println("Deposited successfully.");
				System.out.println("Your account balance is: " + Dao.hm().get(bankBeanDepObj.getAccNo()).getBalance());
			}

			else {

				System.out.println("No such Account Exist.");
			}
		}
	}

	public void withdrawService(BankBean bankBeanWithdrawObj) {
		if (Dao.hm().isEmpty()) {
			System.out.println("Please create an account first.");

		} else

		{
			if (bankBeanWithdrawObj.getWithdrawAmount() > Dao.hm().get(bankBeanWithdrawObj.getAccNo()).getBalance()) 
			{
				System.out.println("Can't withdraw money. Account Balance is low.");
			} 
			else 
			{
				if (Dao.hm().containsKey(bankBeanWithdrawObj.getAccNo())) 
				{
					float dep = Dao.hm().get(bankBeanWithdrawObj.getAccNo()).getBalance()
							- bankBeanWithdrawObj.getWithdrawAmount();
					Dao.hm().get(bankBeanWithdrawObj.getAccNo()).setBalance(dep);
					System.out.println("Withdraw successful.");
					System.out.println(
							"Your account balance is: " + Dao.hm().get(bankBeanWithdrawObj.getAccNo()).getBalance());
				} 
				else 
				{
					System.out.println("No such Account Exist.");

				}

			}

		}

	}

	public void transferService(BankBean bankBeanFundTransObj) {

		if (Dao.hm().isEmpty()) {

			System.out.println("Please create an account first.");

		}

		else {

			if (Dao.hm().containsKey(bankBeanFundTransObj.getSourceAccNo())) {

				if (Dao.hm().containsKey(bankBeanFundTransObj.getDestAccNo())) {
					if (Dao.hm().get(bankBeanFundTransObj.getSourceAccNo()).getBalance() > bankBeanFundTransObj
							.getTransferAmount()) {
						float transfer = bankBeanFundTransObj.getTransferAmount();
						Dao.hm().get(bankBeanFundTransObj.getSourceAccNo()).setBalance(
								Dao.hm().get(bankBeanFundTransObj.getSourceAccNo()).getBalance() - transfer);
						Dao.hm().get(bankBeanFundTransObj.getDestAccNo()).setBalance(
								Dao.hm().get(bankBeanFundTransObj.getDestAccNo()).getBalance() + transfer);
						System.out.println("Funds Transferred Successfully.");
						System.out.println(
								"Remaining balance in account number " + bankBeanFundTransObj.getSourceAccNo() + " is: "
										+ Dao.hm().get(bankBeanFundTransObj.getSourceAccNo()).getBalance());

					} else {
						System.out.println("Can't transfer money. Source Account Balance is low.");
					}
				} else {
					System.out.println("Destination Account Not Exist.");
				}
			}

			else {
				System.out.println("Source Account Not Exist.");

			}

		}

	}

}