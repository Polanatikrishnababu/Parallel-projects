package com.cg.bank.exception;

public class CustomException extends Exception{
	public CustomException()
	{
		
	}
	public CustomException(String msg)
	{
		super(msg);
	}
}
