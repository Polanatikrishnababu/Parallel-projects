package capgemini.bankXYZ.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.bankXYZ.bean.CustomerDetails;
import capgemini.bankXYZ.dbUtil.DbUtil;

public class BankXYZDaoImpl implements BankXYZDao{
	
	private Connection connection;
	PreparedStatement prepStmt ;
	double accountBal;

	@Override
	public CustomerDetails save(CustomerDetails c) {
		
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("insert into XYZbank values(?,?,?,?,?,?)");
			prepStmt.setString(1, c.getFname());
			prepStmt.setString(2, c.getLname());
			prepStmt.setLong(3, c.getPhnum());
			prepStmt.setLong(4, c.getAadharnum());
			prepStmt.setLong(5, c.setAcountnum());
			prepStmt.setDouble(6, c.getMoney());
			int i = prepStmt.executeUpdate();
			if(i>0)
				System.out.println("Customer inserted Successfully!!!!");
		}
		catch(SQLException e1)
		{
			System.err.println("Something went wrong");
			e1.printStackTrace();
		}
		return null;
	}

	@Override
	public String showBal(long accnum) {
		
		connection = DbUtil.getConnection();
		ResultSet rs;
		CustomerDetails c = new CustomerDetails();
		try {
			prepStmt = connection.prepareStatement("select money from XYZbank where acnum = ?");
			prepStmt.setLong(1, accnum);
			rs = prepStmt.executeQuery();
			while(rs.next())
			{
				try {
				return Long.toString(rs.getLong(1));
				}
				catch(SQLException e1)
				{
					e1.printStackTrace();
				}
			}
		}
		catch(SQLException e1)
		{
			System.out.println("No such Account Number");
			e1.printStackTrace();
		}	
		return Double.toString(c.getMoney());
	}

	@Override
	public void deposit(long acnum, double money1) {
		
		
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("select money from XYZbank where acnum = ?");
			prepStmt.setLong(1, acnum);
			ResultSet rs = prepStmt.executeQuery();
			while(rs.next())
			{
				accountBal = rs.getDouble(1);
				prepStmt = connection.prepareStatement("update XYZbank set money = ? where acnum = ?");
				prepStmt.setDouble(1, accountBal+money1);
				prepStmt.setLong(2, acnum);
					int i =prepStmt.executeUpdate();
					if(i>0)
					{
						System.out.println("The Balance is: "+(accountBal+money1));
					}				
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void withdraw(long acnum1, double money) {
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("select money from XYZbank where acnum = ?");
			prepStmt.setLong(1, acnum1);
			ResultSet rs = prepStmt.executeQuery();
			while(rs.next())
			{
				accountBal = rs.getDouble(1);
				if(accountBal>=money)
				{
					prepStmt = connection.prepareStatement("update XYZbank set money = ? where acnum = ?");
					prepStmt.setDouble(1, accountBal-money);
					prepStmt.setLong(2, acnum1);
					int i = prepStmt.executeUpdate();
					if(i>0)
					{
						System.out.println("The Balance is: "+(accountBal-money));
					}
				}
				
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public double transfer(long yaccnum, long raccnum, long amt) {
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("select money from XYZbank where acnum = ?");
			prepStmt.setLong(1, yaccnum);
			ResultSet rs = prepStmt.executeQuery();
			while(rs.next())
			{
				accountBal = rs.getDouble(1);
				if(accountBal >= amt)
				{
					prepStmt = connection.prepareStatement("update XYZbank set money = ? where acnum = ?");
					prepStmt.setDouble(1, accountBal-amt);
					prepStmt.setLong(2, yaccnum);
					int i = prepStmt.executeUpdate();
					if(i>0)
					{
						return accountBal-amt;
					}
				}
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}	
}
