package capgemini.bankXYZ.dao;

import capgemini.bankXYZ.bean.CustomerDetails;

public interface BankXYZDao {

	CustomerDetails save(CustomerDetails c);

	String showBal(long accnum);

	void deposit(long acnum, double money1);

	void withdraw(long acnum1, double money);

	double transfer(long yaccnum, long raccnum, long amt);

}
