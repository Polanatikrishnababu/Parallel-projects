package capgemini.bankXYZ.bean;

public class CustomerDetails {
	
	private String fname;
	private String lname;
	private long phnum;
	private long aadharnum;
	private long accountnum;
	private double money;
	
	public CustomerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerDetails(String fname, String lname, long phnum, long aadharnum, long accountnum, double money) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.phnum = phnum;
		this.aadharnum = aadharnum;
		this.accountnum = accountnum;
		this.money = money;
	}

	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}

	public long getPhnum() {
		return phnum;
	}
	public void setPhnum(long phnum) {
		this.phnum = phnum;
	}

	public long getAadharnum() {
		return aadharnum;
	}
	public void setAadharnum(long aadharnum) {
		this.aadharnum = aadharnum;
	}

	public long getAccountnum(int i) {
		return accountnum;
	}
	public void setAccountnum(long accountnum) {
		this.accountnum = accountnum;
	}
	
	public long setAcountnum()
	{
		long accno=(long) ((Math.random() * ((9999 - 999) + 1)) + 999); 
		return accno;
	}

	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}

	@Override
	public String toString() {
		return "Customer [fname=" + fname + ", lname=" + lname + ", phnum=" + phnum + ", aadharnum=" + aadharnum
				+ ", accountnum=" + accountnum + ", money=" + money + "]";
	}
}
